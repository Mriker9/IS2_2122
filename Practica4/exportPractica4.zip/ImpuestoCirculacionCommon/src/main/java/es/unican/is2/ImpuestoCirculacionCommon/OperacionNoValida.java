package es.unican.is2.ImpuestoCirculacionCommon;
@SuppressWarnings("serial")
public class OperacionNoValida extends Exception {

	public OperacionNoValida(String string) {
		super(string);
	}

}
