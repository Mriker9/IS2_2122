package es.unican.is2.ImpuestoCirculacionCommon;

@SuppressWarnings("serial")
public class DatoInvalido extends Exception {

}
